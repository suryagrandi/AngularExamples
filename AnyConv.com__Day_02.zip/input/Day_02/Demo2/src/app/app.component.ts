import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<h1>Component is the main Building Block in Angular</h1> <h2>Angular 8 Samples</h2>',
  styles: ['h1{color:red;font-weight:bold}','h2{color:blue}']
})
export class AppComponent {
  
}