import { Component } from '@angular/core';

@Component({
  selector: 'child',
  templateUrl: './child.component.html',
  styleUrls : ['./custom.css']
})
export class ChildComponent {
    
}