import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls : ['./custom.css']
})
export class AppComponent implements OnInit {
    private formData: any = {};
    private showMessage: boolean = false;

    constructor() {
    }

    ngOnInit(): void {
    }

    registerUser(formdata: NgForm) {
        this.formData = formdata.value;
        this.showMessage = true;
    }
}