import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private route:Router) { }
  click:boolean=true;

  ngOnInit() {
  }

  


  firstname='';
  lastname='';
  proname='';
 pp(){

   console.log(this.firstname[0]);
   console.log(this.lastname[0]);
   this.proname=this.firstname+" "+this.lastname;
   console.log( this.proname);
   localStorage.setItem("pp",this.proname);
   this.route.navigate(['/avatar']);
   this.click=false;

  
 }

}
