import { Component } from '@angular/core';
import { country } from './country';
import { State } from '../state';
import { StateService } from './state.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'countries';

  selectedCountry: country = new country(2, 'USA');
  countries: country[];
  states: State[];

  constructor(private selectService: StateService) { }

  ngOnInit() {
    this.countries = this.selectService.getCountries();
    this.onSelect(this.selectedCountry.id);
  }

  onSelect(countryid) {
    this.states = this.selectService.getStates().filter((item) => item.countryid == countryid);
  }
}
