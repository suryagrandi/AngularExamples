import { Injectable } from '@angular/core';
import { country } from './country';
import { State } from '../state';
@Injectable({
  providedIn: 'root'
})
export class StateService {

  constructor() { }
  getCountries() {
    return [
     new country(1, 'india' ),
     new country(2, 'usa' ),
    ];
  }
  getStates() {
    return [
      new State(1, 1, 'andhrapradesh' ),
      new State(2, 1, 'telangana' ),
      new State(3, 1, 'maharastra'),
      new State(4, 1, 'kerala'),
      new State(5, 1, 'rajasthan'),
      new State(6, 1, 'goa'),
      new State(7, 1, 'taminadu'),
      new State(8, 1, 'jammu kasmir'),
      new State(9, 1, 'gujarat'),
      
      new State(6, 2, 'california' ),
      new State(7, 2, 'texas'),
      new State(8, 2, 'florida' ),
      new State(9, 2, 'hawali' ),
      new State(10, 2, 'newjersy'),
      new State(11, 2, 'arijona'),
      new State(12, 2, 'jorgia'),
      new State(13, 2, 'ohio'),
     ];
   }
 
}
