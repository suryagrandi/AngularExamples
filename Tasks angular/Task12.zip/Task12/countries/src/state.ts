export class State {
    constructor(public id: number, public countryid: number, public name: string) { }
  }