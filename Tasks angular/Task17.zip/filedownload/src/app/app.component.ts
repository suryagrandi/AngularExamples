import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  public url: string;

  public download(downloadUrl: string): void {
    window.open(downloadUrl, '_blank');
  }
}
