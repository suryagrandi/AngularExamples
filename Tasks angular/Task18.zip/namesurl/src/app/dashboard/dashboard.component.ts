import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  snapshotParam = "initial value";
  subscribedParam = "initial value";
 
  constructor(private readonly route: ActivatedRoute,
    private readonly router: Router,) { }

    ngOnInit() {
      // No Subscription
      this.snapshotParam = this.route.snapshot.paramMap.get("animal");
  
      // Subscribed
      this.route.paramMap.subscribe(params => {
        this.subscribedParam = params.get("animal");
      });
  
    }
    goto(animal: string): void {
      this.router.navigate(["animals", animal]);
    }
  }