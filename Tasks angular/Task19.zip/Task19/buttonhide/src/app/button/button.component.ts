import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.css']
})
export class ButtonComponent {
  a:number=10;
  b:number=20;
  c:number;
 
 private isButtonVisible = true;
  add(){
    this.c=(this.a+this.b);
  }
  }
