# compressImageAngular
Compress image in angular before sending it to api
