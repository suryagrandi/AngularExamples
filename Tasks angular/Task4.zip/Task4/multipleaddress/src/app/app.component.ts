import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormArray } from '@angular/forms';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  constructor( private build:FormBuilder) {
    console.log(this.myform)
   }

  ngOnInit() {
  }

  add(){
    (this.myform.controls.address as FormArray).push(
      this.build.group({
        city:['',Validators.required],
        state:['',Validators.required],
        country:['',Validators.required],
      })
    )
  }



  myform=this.build.group({
    address:this.build.array([
      
      this.build.group({
        city:['',Validators.required],
        state:['',Validators.required],
        country:['',Validators.required],
      }),


    ])
        

  })

}