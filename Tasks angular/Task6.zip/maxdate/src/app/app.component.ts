import { Component } from '@angular/core';
import * as moment from 'moment';
export default moment;

import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  name = 'Angular';

  now = new Date();
  year = this.now.getFullYear();
  month = this.now.getMonth();
  day = this.now.getDay();
  minDate = moment(new Date()).format('YYYY-MM-DD');

  maxDate = "2020-12-10"

  date = new FormControl('', [Validators.required, Validators.min(moment(new Date()).millisecond())])
}
