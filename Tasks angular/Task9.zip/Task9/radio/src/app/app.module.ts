import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms';
import { RadioComponent } from './radio/radio.component'
import {RadioButtonModule} from 'primeng/radiobutton';
@NgModule({
  declarations: [
    AppComponent,
    RadioComponent,
  ],    
  imports: [
    BrowserModule,
    RadioButtonModule,
  AppRoutingModule,
  HttpClientModule,
  FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
