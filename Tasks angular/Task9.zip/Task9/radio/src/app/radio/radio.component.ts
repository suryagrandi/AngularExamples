import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-radio',
  templateUrl: './radio.component.html',
  styleUrls: ['./radio.component.css']
})
export class RadioComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  part1: boolean = false;
  part2: boolean = false;

  makeP1True() {
    this.part1 = true;
    this.part2 = false;
  }

  makeP2True() {
    this.part2 = true;
    this.part1 = false;
  }
}
